using System.Collections;
using Unity.AppUI.UI;
using Unity.VisualScripting;
using UnityEngine;

public class KeyBehaviour : MonoBehaviour
{
    private float elapsed = 0;
    private float yRotation = 0;
    public KeyStates currentState = KeyStates.look;

    public GameObject player;
    public GameObject pathFindingManager;
    public Grid nodePos;
    public PathFinding PathFinding;
    private float moveSpeed = 5f;
    private Node startPos;
    private Node endPos;
    private Node getNode;
    private Vector3 target;
    private float time = 3f;
    private float cooldown = 0.5f;
    private bool isChasing = false;
    public GameObject finish;
    public Finish increase;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        player = GameObject.Find("Capsule");
        pathFindingManager = GameObject.Find("Plane");
        nodePos = pathFindingManager.GetComponent<Grid>();
        PathFinding = pathFindingManager.GetComponent<PathFinding>();
    }

    // Update is called once per frame
    void LateUpdate()
    {
        switch (currentState)
        {
            case KeyStates.look:
                HandleLook();
                break;
            case KeyStates.flee:
                HandleFlee();
                break;
            case KeyStates.collected:
                HandleCollected();
                break;
        }
    }

    private void HandleLook()
    {
        elapsed += Time.deltaTime;
        Vector3 lookDirection = new Vector3(transform.eulerAngles.x, yRotation, transform.eulerAngles.z);
        if ( elapsed > 3f)
        {
            yRotation += 90f;
            elapsed = 0;
        }
        transform.rotation = Quaternion.RotateTowards(transform.rotation, Quaternion.Euler(lookDirection), 200f * Time.deltaTime);
        if (Look())
        {
            currentState = KeyStates.flee;
        }

        RaycastHit[] hitting = Physics.SphereCastAll(transform.position, 1f, Vector3.down, 70f);

        foreach (RaycastHit hit in hitting)
        {

            if (hit.collider.tag == "Player")
            {
                currentState = KeyStates.collected;
            }
        }
    }

    private bool Look()
    {
        RaycastHit hit;
        Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit, 10f);
        Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward), Color.cyan, 3f);
        if (hit.collider == null)
        {
            return false;
        }
        if (hit.collider.tag == "Player")
        {
            //Debug.Log("I see you");
            return true;
        }
        return false;
    }

    private void HandleFlee()
    {
        time += Time.deltaTime;
        if (time>= cooldown)
        {
            time = 0;
            target = transform.position + (transform.position - player.transform.position);
            StopAllCoroutines();
            StartCoroutine(Flee());
            RaycastHit[] hits = Physics.SphereCastAll(transform.position, 7f, Vector3.back, 10f);
            isChasing = false;
            foreach (RaycastHit hit in hits)
            {

                if (hit.collider.tag == "Player")
                {
                    isChasing = true;
                }
            }
            if (!isChasing)
            {
                currentState = KeyStates.look;
            }

        }
        RaycastHit[] hitting = Physics.SphereCastAll(transform.position, 1f, Vector3.down, 10f);

        foreach (RaycastHit hit in hitting)
        {

            if (hit.collider.tag == "Player")
            {
                currentState = KeyStates.collected;
            }
        }
    }

    private IEnumerator Flee()
    {
        startPos = nodePos.NodeFromWorldPoint(transform.position);
        endPos = nodePos.NodeFromWorldPoint(target);
        var path = PathFinding.FindPath(startPos, endPos);
        if (path == null || path.Count == 0)
        {
            yield break; // Exit the coroutine
        }
        path.Reverse();
        foreach (Node node in path)
        {

            Vector3 targetPosition = new Vector3(node.worldPosition.x, 0.5f, node.worldPosition.z);

            // Move gradually towards the next node in the path
            while (Vector3.Distance(transform.position, targetPosition) > 0.01f)
            {
                target = (targetPosition - transform.position).normalized;

                target.y = 0;

                if (target != Vector3.zero)
                {
                    Quaternion lookRotation = Quaternion.LookRotation(target);
                    transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, 5f * Time.deltaTime);
                }

                transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
                yield return null; // Wait for one frame
            }
        }
        yield return null;
    }

    private void HandleCollected()
    {
        RaycastHit[] hits = Physics.SphereCastAll(transform.position, 1f, Vector3.down, 10f);

        foreach (RaycastHit hit in hits)
        {

            if (hit.collider.tag == "Player")
            {
                finish = GameObject.Find("Finish(Clone)");
                increase = finish.GetComponent<Finish>();
                increase.IncreaseKey();
                Destroy(gameObject);
            }
        }
    }
}
