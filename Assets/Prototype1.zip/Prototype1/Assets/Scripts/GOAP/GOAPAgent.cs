using System.Collections.Generic;
using UnityEngine;

public abstract class GOAPAgent : MonoBehaviour
{
    public GOAPPlanner planner;
    private Queue<GOAPAction> currentPlan;
    private GOAPAction currentAction;

    float timer = 0f;

    public HashSet<GOAPAction> actions;
    public Dictionary<string, bool> WorldState = new Dictionary<string, bool>();
    public Dictionary<string, bool> goal = new Dictionary<string, bool>();

    public Animator animator;

    void Start()
    {
        planner = new GOAPPlanner();
        actions = new HashSet<GOAPAction>(GetComponents<GOAPAction>());
    }

    private void Update()
    {
        timer += Time.deltaTime;
        if (timer > 3f)
        {
            animator.SetBool("isIdle", true);
            animator.SetBool("isWalking", false);
            animator.SetBool("isCharging", false);
            WorldState = GetWorldState();
            goal = CreateGoalState();

            currentPlan = planner.Plan(actions, WorldState, goal);
            if (currentPlan != null && currentPlan.Count > 0)
            {
                var action = currentPlan.Peek();
                if (!action.isRunning)
                {
                    action.isRunning = true;
                    action.PerformAction(gameObject);
                }
                if (timer > 3f)
                {
                    action.isRunning = false;
                }

                if (action.isDone())
                {
                    currentPlan.Dequeue();
                    Debug.Log(currentPlan.Count);
                }
            }
            timer = 0;
        }
    }

    public abstract Dictionary<string, bool> GetWorldState();
    public abstract Dictionary<string, bool> CreateGoalState();

}
