using System.Collections.Generic;
using UnityEngine;

public class RageAgent : GOAPAgent
{
    float radius = 2f;
    float rageThreshold = 25;
    float rageValue;

    public override Dictionary<string, bool> GetWorldState()
    {
        Collider[] objects = Physics.OverlapSphere(transform.position, radius);
        rageValue = objects.Length;
        Debug.Log(rageValue);

        var worldState = new Dictionary<string, bool>()
        {
            {"isCalm", rageValue < rageThreshold },
            { "isRaging", rageValue >= rageThreshold }
        };
        return worldState;
    }

    public override Dictionary<string, bool> CreateGoalState()
    {
        var goal = new Dictionary<string, bool>();

        if (rageValue >= rageThreshold)
        {
            goal.Add("destroyObjects", true);
            //Debug.Log("AmFuming");
        }
        else
        {
            goal.Add("StayCalm", true);
        }

        return goal;
    }
}
