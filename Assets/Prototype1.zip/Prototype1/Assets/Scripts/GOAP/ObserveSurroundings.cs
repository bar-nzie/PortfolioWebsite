using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class ObserveSurroundings : GOAPAction
{
    public Grid nodePos;
    public PathFinding PathFinding;
    private Node startPos;
    private Node endPos;
    private Vector3 target;
    private float moveSpeed = 2f;
    public GameObject pathFindingManager;
    public Animator animator;

    private void Awake()
    {
        preconditions.Add("isCalm", true);
        effects.Add("StayCalm", true );
        cost = 1f;
    }

    void Start()
    {
        pathFindingManager = GameObject.Find("Plane");
        nodePos = pathFindingManager.GetComponent<Grid>();
        PathFinding = pathFindingManager.GetComponent<PathFinding>();
    }

    public override void PerformAction(GameObject agent)
    {
        StopAllCoroutines();
        animator.SetBool("isIdle", false);
        animator.SetBool("isWalking", true);
        animator.SetBool("isCharging", false);
        StartCoroutine(MoveTo());
    }

    private IEnumerator MoveTo()
    {
        target = new Vector3(transform.position.x + Random.Range(-5f, 5f), transform.position.y, transform.position.z + Random.Range(-5f, 5f));
        startPos = nodePos.NodeFromWorldPoint(transform.position);
        if (target.x > 49 || target.x < 1 || target.z > 49 || target.z < 1)
        {
            StopAllCoroutines();
            yield return null;
        }
        endPos = nodePos.NodeFromWorldPoint(target);
        if (endPos.walkable == false)
        {
            StopAllCoroutines();
            yield return null;
        }
        var path = PathFinding.FindPath(startPos, endPos);

        path.Reverse();
        foreach (Node node in path)
        {
            Vector3 targetPosition = new Vector3(node.worldPosition.x, 0.5f, node.worldPosition.z);
            //Debug.Log(targetPosition);

            // Move gradually towards the next node in the path
            while (Vector3.Distance(transform.position, targetPosition) > 0.01f)
            {
                Vector3 direction = (targetPosition - transform.position).normalized;

                direction.y = 0;

                if (direction != Vector3.zero)
                {
                    Quaternion lookRotation = Quaternion.LookRotation(direction);
                    transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, 5f * Time.deltaTime);
                }

                transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
                yield return null; // Wait for one frame
            }
        }
        animator.SetBool("isWalking", false);
        animator.SetBool("isIdle", true);
    }

    public override bool isDone() => !isRunning;
}
