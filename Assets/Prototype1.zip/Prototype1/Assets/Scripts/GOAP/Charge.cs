using System.Collections;
using UnityEngine;

public class Charge : GOAPAction
{
    private float duration = 3f;
    private Rigidbody rb;
    private int direction;

    public Animator animator;

    private void Awake()
    {
        preconditions.Add("isRaging", true);
        effects.Add("destroyObjects", true);
        cost = 0.5f;
    }

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    public override void PerformAction(GameObject agent)
    {
        animator.SetBool("isIdle", false);
        animator.SetBool("isWalking", false);
        animator.SetBool("isCharging", true);
        StartCoroutine(Charging());
    }

    private IEnumerator Charging()
    {
        direction = Random.Range(0, 3);
        float elapsed = 0f;
        while (elapsed < duration)
        {
            Collider[] hits = Physics.OverlapSphere(transform.position, 0.01f);
            foreach (var hit in hits)
            {
                if (hit.CompareTag("wall"))
                {
                    Destroy(hit.gameObject);
                }
            }
            elapsed += Time.deltaTime;
            if (direction == 0)
            {
                transform.position += new Vector3(0.05f, 0, 0);
                Quaternion lookRot = Quaternion.LookRotation(Vector3.right);
                transform.rotation = Quaternion.Slerp(transform.rotation, lookRot, 10f * Time.deltaTime);
            }
            else if (direction == 1)
            {
                transform.position += new Vector3(-0.05f, 0, 0);
                Quaternion lookRot = Quaternion.LookRotation(Vector3.left);
                transform.rotation = Quaternion.Slerp(transform.rotation, lookRot, 10f * Time.deltaTime);
            }
            else if (direction == 2)
            {
                transform.position += new Vector3(0, 0, 0.05f);
                Quaternion lookRot = Quaternion.LookRotation(Vector3.forward);
                transform.rotation = Quaternion.Slerp(transform.rotation, lookRot, 10f * Time.deltaTime);
            }
            else
            {
                transform.position += new Vector3(0, 0, -0.05f);
                Quaternion lookRot = Quaternion.LookRotation(Vector3.back);
                transform.rotation = Quaternion.Slerp(transform.rotation, lookRot, 10f * Time.deltaTime);
            }
            yield return null;
        }
        if (elapsed > duration)
        {
            isRunning = false;
            isDone();
            animator.SetBool("isCharging", false);
            animator.SetBool("isIdle", true);
        }
    }
    public override bool isDone() => !isRunning;
}
