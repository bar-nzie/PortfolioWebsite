using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class GOAPPlanner
{
    public Queue<GOAPAction> Plan(HashSet<GOAPAction> actions, Dictionary<string, bool> WorldState, Dictionary<string, bool> goal)
    {
        var usableActions = actions.Where(a => a.preconditions.All(p => WorldState.ContainsKey(p.Key) && WorldState[p.Key] == p.Value)).ToList();

        foreach (var action in usableActions)
        {
            foreach (var effect in action.effects)
            {
                if (goal.ContainsKey(effect.Key) && goal[effect.Key] == effect.Value)
                {
                    var plan = new Queue<GOAPAction>();
                    plan.Enqueue(action);
                    return plan;
                }
            }
        }
        return null;
    }
}
