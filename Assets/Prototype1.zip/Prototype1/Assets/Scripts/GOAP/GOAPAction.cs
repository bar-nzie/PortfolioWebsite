using System.Collections.Generic;
using UnityEngine;

public abstract class GOAPAction : MonoBehaviour
{
    public Dictionary<string, bool> preconditions = new Dictionary<string, bool>();
    public Dictionary<string, bool> effects = new Dictionary<string, bool>();
    public float cost = 1f;

    public bool isRunning;
    public abstract bool isDone();
    public abstract void PerformAction(GameObject agent);
}
