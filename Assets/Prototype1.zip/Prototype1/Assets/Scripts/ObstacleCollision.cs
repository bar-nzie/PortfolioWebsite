using Unity.VisualScripting;
using UnityEngine;

public class ObstacleCollision : MonoBehaviour
{
    private void Update()
    {
        Collider[] hits = Physics.OverlapSphere(transform.position, 0.01f);
        foreach (var hit in hits)
        {
            if (hit.CompareTag("wall"))
            {
                Destroy(hit.gameObject);
            }
        }
    }
}
