using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class PathFinding : MonoBehaviour
{
    public Grid grids;

    private void Awake()
    {
        grids = GetComponent<Grid>();
    }
    public List<Node> FindPath(Node startNode, Node endNode)
    {
        var toSearch = new List<Node>() { startNode };
        //if (endNode.walkable ==  false)
        //{
        //    Debug.Log("walkable?");
        //    return null;
        //}
        var processed = new List<Node>();
        int count = 0;

        while(toSearch.Any())
        {
            var current = toSearch[0];
            foreach (var t in toSearch)
            {
                if (t.fCost < current.fCost || t.fCost == current.fCost && t.hCost < current.hCost)
                {
                    current = t;
                }
            }
            processed.Add(current);
            toSearch.Remove(current);

            if(current == endNode)
            {
                var currentPathTile = endNode;
                var path = new List<Node>();
                while (currentPathTile != startNode)
                {
                    path.Add(currentPathTile);
                    //Debug.Log(path);
                    currentPathTile = currentPathTile.parent;
                }
                return path;
            }

            foreach (var neighbour in grids.GetNeighbours(current).Where(t => t.walkable && !processed.Contains(t)))
            {
                var inSearch = toSearch.Contains(neighbour);

                var costToNeighbour = current.gCost + GetDistance(current, neighbour);

                if(!inSearch || costToNeighbour < neighbour.gCost)
                {
                    neighbour.gCost = costToNeighbour;
                    neighbour.parent = current;

                    if (!inSearch)
                    {
                        neighbour.hCost = costToNeighbour;
                        toSearch.Add(neighbour);
                    }
                }
            }
            count++;
        }
        return null;
    }

    int GetDistance(Node a, Node b)
    {
        int dstX = Mathf.Abs(a.gridX - b.gridX);
        int dstY = Mathf.Abs(a.gridY - b.gridY);

        if(dstX> dstY)
        {
            return 14 * dstY + 10 * (dstX - dstY);
        }
        return 14 * dstX + 10 * (dstY - dstX);
    }
}
