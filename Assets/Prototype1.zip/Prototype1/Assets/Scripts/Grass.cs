using UnityEngine;

public class Grass : MonoBehaviour
{
    private float chance;
    public GameObject bush;
    public GameObject pathFindingManager;
    public Grid nodePos;
    private Node pos;
    private bool hasGrown;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        pathFindingManager = GameObject.Find("Plane");
        nodePos = pathFindingManager.GetComponent<Grid>();
    }

    // Update is called once per frame
    void Update()
    {
        chance = Random.Range(0, 10000f);
        if (chance < 0.1 && hasGrown == false)
        {
            hasGrown = true;
            Instantiate( bush, transform.position, Quaternion.identity );
            pos = nodePos.NodeFromWorldPoint(transform.position);
            pos.walkable = false;
        }
    }
}
