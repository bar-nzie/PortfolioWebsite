using UnityEngine;

public class Floor : MonoBehaviour
{
    private Renderer rend;
    private Color originalColour;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rend = GetComponent<Renderer>();
        originalColour = rend.material.color;
    }

    // Update is called once per frame
    void Update()
    {
        rend.material.color = originalColour;
    }
}
