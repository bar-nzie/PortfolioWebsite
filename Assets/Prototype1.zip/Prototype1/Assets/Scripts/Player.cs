using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEditor.XR;
using UnityEngine;
using UnityEngine.Animations;
using UnityEngine.InputSystem;

public class Player : MonoBehaviour
{
    public Camera cam;
    public Grid nodePos;
    public PathFinding PathFinding;
    public ButtonPress button;
    private Node startPos;
    private Node endPos;
    public float moveSpeed = 2f;
    private Vector2 screenPos;
    private Vector3 target;
    Ray ray;
    private bool readyToMove = true;
    public Renderer rend;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            screenPos = Mouse.current.position.ReadValue();
            ray = cam.ScreenPointToRay(screenPos);
            RaycastHit hit;
            Debug.DrawRay(ray.origin, ray.direction * 1000f, Color.red, 0.1f);

            if (Physics.Raycast(ray, out hit, 1000f))
            {
                if (hit.collider.tag == "Ground")
                {
                    StopAllCoroutines();
                    target = hit.collider.gameObject.transform.position;
                    StartCoroutine(Movement());
                }
                if (hit.collider.tag == "Button")
                {
                    button = hit.collider.gameObject.GetComponent<ButtonPress>();
                    button.ButtonPresser();
                }
            }
        }

        RaycastHit[] hits = Physics.SphereCastAll(transform.position, 0.25f, Vector3.down, 10f);

        foreach (RaycastHit hit in hits)
        {

            if (hit.collider.tag == "Boss")
            {
                Destroy(gameObject);
            }
        }
    }

    private IEnumerator Movement()
    {
        startPos = nodePos.NodeFromWorldPoint(transform.position);
        //Debug.Log(transform.position);
        endPos = nodePos.NodeFromWorldPoint(target);
        var path = PathFinding.FindPath(startPos, endPos);
        if (path == null || path.Count == 0)
        {
            yield break; // Exit the coroutine
        }
        path.Reverse();
        foreach (Node node in path)
        {
            
            Vector3 targetPosition = new Vector3(node.worldPosition.x, 0.5f, node.worldPosition.z);
            //Debug.Log(targetPosition);

            // Move gradually towards the next node in the path
            while (Vector3.Distance(transform.position, targetPosition) > 0.01f || readyToMove == false)
            {
                Vector3 direction = (targetPosition - transform.position).normalized;

                direction.y = 0;

                if (direction != Vector3.zero)
                {
                    Quaternion lookRotation = Quaternion.LookRotation(direction);
                    transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, 5f * Time.deltaTime);
                }

                transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
                yield return null; // Wait for one frame
            }
        }
        readyToMove = true;
    }
}
