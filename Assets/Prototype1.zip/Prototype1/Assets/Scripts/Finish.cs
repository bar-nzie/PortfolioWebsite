using UnityEngine;
using UnityEngine.SceneManagement;

public class Finish : MonoBehaviour
{
    public NPCBehaviour npc;
    public GameObject GameObject;
    private bool unlocked;
    private float keys;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        GameObject = GameObject.Find("NPC");
        npc = GameObject.GetComponent<NPCBehaviour>();
    }

    // Update is called once per frame
    void Update()
    {
        unlocked = npc.GetUnlockStatus();
        Vector3 rayOrigin = transform.position;
        Vector3 rayDirection = Vector3.up;

        if (Physics.Raycast(rayOrigin, rayDirection, out RaycastHit hit, 5f))
        {
            // Check if the hit object has the tag "player"
            if (hit.collider.CompareTag("Player"))
            {
                if (unlocked && keys == 4)
                {
                    SceneManager.LoadScene(0);
                }
            }
        }
    }

    public void IncreaseKey()
    {
        keys++;
    }
}
