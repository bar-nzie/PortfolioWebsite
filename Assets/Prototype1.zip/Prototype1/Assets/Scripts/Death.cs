using UnityEngine;

public class Death : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(transform.position.x > 50 || transform.position.x < 0 || transform.position.z > 50 || transform.position.z < 0)
        {
            Destroy(gameObject);
        }
    }
}
