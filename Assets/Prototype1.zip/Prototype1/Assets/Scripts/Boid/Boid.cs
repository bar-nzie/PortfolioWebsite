using UnityEngine;

public class Boid : MonoBehaviour
{
    public Vector3 velocity;
    public float maxSpeed = 5f;

    private void Start()
    {
        velocity = new Vector3(Random.Range(0f, 5f), 0f, Random.Range(0f, 5f));
    }

    public Vector3 Cohesion(Boid[] neighbors)
    {
        Vector3 centerOfMass = Vector3.zero;
        int count = 0;

        foreach (Boid neighbor in neighbors)
        {
            if (neighbor != this)
            {
                centerOfMass += neighbor.transform.position;
                count++;
            }
        }

        if (count > 0)
        {
            centerOfMass /= count;
            return (centerOfMass - transform.position).normalized;
        }

        return Vector3.zero;
    }

    public Vector3 Separation(Boid[] neighbors, float separationRadius)
    {
        Vector3 moveAway = Vector3.zero;
        int count = 0;

        foreach (Boid neighbor in neighbors)
        {
            if (neighbor != this && Vector3.Distance(transform.position, neighbor.transform.position) < separationRadius)
            {
                Vector3 difference = transform.position - neighbor.transform.position;
                moveAway += difference.normalized / difference.magnitude; // Key optimization: Inverse scaling
                count++;
            }
        }

        if (count > 0)
        {
            moveAway /= count;
        }

        return moveAway.normalized;
    }

    public Vector3 Alignment(Boid[] neighbors)
    {
        Vector3 averageVelocity = Vector3.zero;
        int count = 0;

        foreach (Boid neighbor in neighbors)
        {
            if (neighbor != this)
            {
                averageVelocity += neighbor.velocity;
                count++;
            }
        }

        if (count > 0)
        {
            averageVelocity /= count;
            return averageVelocity.normalized;
        }

        return Vector3.zero;
    }

    public Vector3 StayInBounds(Vector3 center, float boundRadius, float turnStrength)
    {
        Vector3 offset = transform.position - center;
        float distance = offset.magnitude;


        if (distance < boundRadius)
            return Vector3.zero;
    
        Vector3 directionToCenter = -offset.normalized;
        return directionToCenter * turnStrength;

    }


}

//ref: https://www.wayline.io/blog/practical-flocking-unity-boid-system