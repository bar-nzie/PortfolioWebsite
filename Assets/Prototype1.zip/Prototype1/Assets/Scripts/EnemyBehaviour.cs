using System.Collections;
using System.Linq;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UIElements;

public class EnemyBehaviour : MonoBehaviour
{
    public GameObject player;
    public GameObject pathFindingManager;
    public Grid nodePos;
    public PathFinding PathFinding;
    private float moveSpeed = 2f;
    private Node startPos;
    private Node endPos;
    private Node getNode;
    private Vector3 target;
    private float cooldown = 2f;
    private float cooldown1 = 1f;
    private float time = 0f;
    private float chaseTime = 0f;
    private float chaseCooldown = 5f;
    private float attackTime = 0f;
    private float attackCooldown = 2f;
    private float radius = 3f;
    public LayerMask obstacleMask;
    public GameObject bullet;
    private Vector3 playerPos;
    private int count;
    public Animator enemyAnimations;

    public EnemyStates currentState = EnemyStates.idle;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        player = GameObject.Find("Capsule");
        pathFindingManager = GameObject.Find("Plane");
        nodePos = pathFindingManager.GetComponent<Grid>();
        PathFinding = pathFindingManager.GetComponent<PathFinding>();
        cooldown = Random.Range(1f, 3f);
        enemyAnimations.SetBool("isIdle", true);
    }

    // Update is called once per frame
    void LateUpdate()
    {
        switch (currentState)
        {
            case EnemyStates.idle:
                enemyAnimations.SetBool("isIdle", false);
                enemyAnimations.SetBool("isPatrolling", true);
                enemyAnimations.SetBool("isChasing", false);
                HandleIdle();
                break;
            case EnemyStates.chase:
                enemyAnimations.SetBool("isPatrolling", false);
                enemyAnimations.SetBool("isChasing", true);
                enemyAnimations.SetBool("isAttacking", false);
                HandleChase();
                break;
            case EnemyStates.attacking:
                enemyAnimations.SetBool("isAttacking", true);
                HandleAttack();
                break;
        }
    }

    public void HandleIdle()
    {
        time += Time.deltaTime;
        if (time > cooldown)
        {
            time = 0f;

            StopAllCoroutines();
            StartCoroutine(Idle());
        }
        RaycastHit[] hits = Physics.SphereCastAll(transform.position, radius, Vector3.down, 10f);

        foreach (RaycastHit hit in hits)
        {
            if (hit.collider.tag == "Ground")
            {
                Renderer rend = hit.collider.gameObject.GetComponent<Renderer>();
                Vector3 direction = hit.transform.position - transform.position;
                float distance = Vector3.Distance(transform.position, hit.transform.position);

                if(Physics.Raycast(transform.position, direction, distance, obstacleMask))
                {
                    continue;
                }
                rend.material.color = Color.red;
            }
            else if (hit.collider.tag == "Player")
            {
                currentState = EnemyStates.chase;
            }
        }
    }

    public void HandleChase()
    {
        Debug.Log("Chase");
        time += Time.deltaTime;
        chaseTime += Time.deltaTime;
        if (time > cooldown)
        {
            time = 0f;

            StopAllCoroutines();
            StartCoroutine(ChasePlayer());
        }

        RaycastHit[] hits = Physics.SphereCastAll(transform.position, radius, Vector3.down, 10f);

        foreach (RaycastHit hit in hits)
        {
            
            if (hit.collider.tag == "Player")
            {
                chaseTime = 0f;
            }
        }
        if (chaseTime > chaseCooldown)
        {
            currentState = EnemyStates.idle;
            chaseTime = 0f;
        }

        hits = Physics.SphereCastAll(transform.position, radius / 2, Vector3.down, 10f);

        foreach (RaycastHit hit in hits)
        {

            if (hit.collider.tag == "Player")
            {
                playerPos = hit.collider.transform.position;
                currentState = EnemyStates.attacking;
            }
        }
    }

    public void HandleAttack()
    {
        Debug.Log("Attack");
        RaycastHit[] hits;
        attackTime += Time.deltaTime;
        time += Time.deltaTime;
        if (time > cooldown1)
        {
            time = 0f;

            StopAllCoroutines();
            StartCoroutine(AttackPlayer());
        }

        hits = Physics.SphereCastAll(transform.position, radius / 1.5f, Vector3.down, 10f);

        foreach (RaycastHit hit in hits)
        {

            if (hit.collider.tag == "Player")
            {
                playerPos = hit.collider.transform.position;
                attackTime = 0f;
            }
        }

        if(attackTime > attackCooldown)
        {
            currentState = EnemyStates.chase;
            attackTime = 0f;
        }
    }

    private IEnumerator AttackPlayer()
    {
        Vector3 shootPos = new Vector3(transform.position.x, transform.position.y + 1, transform.position.z);
        Vector3 direction = playerPos - shootPos;
        GameObject currentBullet = Instantiate(bullet, shootPos, Quaternion.identity);
        currentBullet.GetComponent<Rigidbody>().AddForce(direction.normalized * 5f, ForceMode.Impulse);
        
        yield return null;

        
    }

    private IEnumerator ChasePlayer()
    {
        count = 0;
        target = player.transform.position;
        startPos = nodePos.NodeFromWorldPoint(transform.position);
        startPos.walkable = false;
        endPos = nodePos.NodeFromWorldPoint(target);
        var path = PathFinding.FindPath(startPos, endPos);

        path.Reverse();
        foreach (Node node in path)
        {
            if (count == path.LastIndexOf(node) - 1)
            {
                continue;
            }
            Vector3 targetPosition = new Vector3(node.worldPosition.x, 0.5f, node.worldPosition.z);
            //Debug.Log(targetPosition);

            // Move gradually towards the next node in the path
            while (Vector3.Distance(transform.position, targetPosition) > 0.01f)
            {
                Vector3 direction = (targetPosition - transform.position).normalized;

                direction.y = 0;

                if (direction != Vector3.zero)
                {
                    Quaternion lookRotation = Quaternion.LookRotation(direction);
                    transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, 5f * Time.deltaTime);
                }

                transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
                startPos.walkable = true;
                yield return null; // Wait for one frame
            }
            count++;
        }
    }

    private IEnumerator Idle()
    {
        target = new Vector3(transform.position.x + Random.Range(-5f, 5f), transform.position.y, transform.position.z + Random.Range(-5f, 5f));
        startPos = nodePos.NodeFromWorldPoint(transform.position);
        if (target.x > 49 || target.x < 1 || target.z > 49 || target.z < 1)
        {
            yield break;
        }
        endPos = nodePos.NodeFromWorldPoint(target);
        if (endPos.walkable == false)
        {
            yield break;
        }
        var path = PathFinding.FindPath(startPos, endPos);

        path.Reverse();
        foreach (Node node in path)
        {
            Vector3 targetPosition = new Vector3(node.worldPosition.x, 0.5f, node.worldPosition.z);
            //Debug.Log(targetPosition);

            // Move gradually towards the next node in the path
            while (Vector3.Distance(transform.position, targetPosition) > 0.01f)
            {
                Vector3 direction = (targetPosition - transform.position).normalized;

                direction.y = 0;

                if (direction != Vector3.zero)
                {
                    Quaternion lookRotation = Quaternion.LookRotation(direction);
                    transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, 5f * Time.deltaTime);
                }

                transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
                yield return null; // Wait for one frame
            }
        }
    }
}
