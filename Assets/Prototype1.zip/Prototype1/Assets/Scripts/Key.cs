using UnityEngine;

public class Key : MonoBehaviour
{
    private bool isUp = false;
    // Update is called once per frame
    void Update()
    {
        if (isUp)
        {
            transform.position += new Vector3(0, 0.01f, 0);
        }
        if (!isUp)
        {
            transform.position -= new Vector3(0, 0.01f, 0);
        }
        if (transform.position.y <= 0.5)
        {
            isUp = true;
        }
        if (transform.position.y >= 1.5)
        {
            isUp = false;
        }
    }
}
