using System.Collections;
using Unity.AppUI.UI;
using Unity.VisualScripting;
using UnityEngine;

public class NPCBehaviour : MonoBehaviour
{
    public GameObject player;
    public GameObject pathFindingManager;
    public Grid nodePos;
    public PathFinding PathFinding;
    private float moveSpeed = 5f;
    private Node startPos;
    private Node endPos;
    private Node getNode;
    private Vector3 target;
    private float cooldown = 0.5f;
    private float time = 0f;
    private float radius = 3f;
    private Vector3 enemyPos;
    public bool unlock;

    public NPCStates currentState = NPCStates.follow;
    void Start()
    {
        player = GameObject.Find("Capsule");
        pathFindingManager = GameObject.Find("Plane");
        nodePos = pathFindingManager.GetComponent<Grid>();
        PathFinding = pathFindingManager.GetComponent<PathFinding>();
        cooldown = Random.Range(1f, 3f);
    }

    // Update is called once per frame
    void LateUpdate()
    {
        switch (currentState)
        {
            case NPCStates.follow:
                unlock = true;
                HandleFollow();
                break;
            case NPCStates.flee:
                unlock = false;
                HandleFlee();
                break;
        }
    }

    public bool GetUnlockStatus() {  return unlock; }

    public void HandleFollow()
    {
        time += Time.deltaTime;
        if (time > cooldown)
        {
            time = 0f;

            StopAllCoroutines();
            StartCoroutine(Follow());
        }

        RaycastHit[] hits = Physics.SphereCastAll(transform.position, radius, Vector3.down, 10f);

        foreach (RaycastHit hit in hits)
        {

            if (hit.collider.tag == "Enemy")
            {
                enemyPos = hit.point;
                currentState = NPCStates.flee;
            }
        }
    }

    public void HandleFlee()
    {
        time += Time.deltaTime;
        if (time > cooldown)
        {
            time = 0f;

            StopAllCoroutines();
            StartCoroutine(Flee());
        }

        RaycastHit[] hits = Physics.SphereCastAll(transform.position, radius / 2, Vector3.down, 10f);

        foreach (RaycastHit hit in hits)
        {

            if (hit.collider.tag == "Player")
            {
                enemyPos = hit.point;
                currentState = NPCStates.follow;
            }
        }
    }

    private IEnumerator Flee()
    {
        Vector3 direction = new Vector3(1.0f, transform.position.y, 1.0f);
        startPos = nodePos.NodeFromWorldPoint(transform.position);
        endPos = nodePos.NodeFromWorldPoint(direction);
        var path = PathFinding.FindPath(startPos, endPos);
        if (path == null || path.Count == 0)
        {
            yield break; // Exit the coroutine
        }
        path.Reverse();
        foreach (Node node in path)
        {

            Vector3 targetPosition = new Vector3(node.worldPosition.x, 0.5f, node.worldPosition.z);

            // Move gradually towards the next node in the path
            while (Vector3.Distance(transform.position, targetPosition) > 0.01f)
            {
                direction = (targetPosition - transform.position).normalized;

                direction.y = 0;

                if (direction != Vector3.zero)
                {
                    Quaternion lookRotation = Quaternion.LookRotation(direction);
                    transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, 5f * Time.deltaTime);
                }

                transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
                yield return null; // Wait for one frame
            }
        }
        yield return null;
    }

    private IEnumerator Follow()
    {
        target = player.transform.position;
        startPos = nodePos.NodeFromWorldPoint(transform.position);
        startPos.walkable = false;
        getNode = nodePos.NodeFromWorldPoint(target);
        var neighbours = nodePos.GetNeighbours(getNode);
        endPos = neighbours[Random.Range(0, neighbours.LastIndexOf(endPos))];
        var path = PathFinding.FindPath(startPos, endPos);

        path.Reverse();
        foreach (Node node in path)
        {
            Vector3 targetPosition = new Vector3(node.worldPosition.x, 0.5f, node.worldPosition.z);

            // Move gradually towards the next node in the path
            while (Vector3.Distance(transform.position, targetPosition) > 0.01f)
            {
                Vector3 direction = (targetPosition - transform.position).normalized;

                direction.y = 0;

                if (direction != Vector3.zero)
                {
                    Quaternion lookRotation = Quaternion.LookRotation(direction);
                    transform.rotation = Quaternion.Slerp(transform.rotation, lookRotation, 5f * Time.deltaTime);
                }

                transform.position = Vector3.MoveTowards(transform.position, targetPosition, moveSpeed * Time.deltaTime);
                startPos.walkable = true;
                yield return null; // Wait for one frame
            }
        }
        yield return null;
    }
}
