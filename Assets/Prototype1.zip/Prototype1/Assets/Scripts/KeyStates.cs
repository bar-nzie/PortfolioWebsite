using UnityEngine;

public enum KeyStates
{
    look,
    flee,
    collected
}
