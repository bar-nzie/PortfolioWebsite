using UnityEngine;

public enum NPCStates
{
    follow,
    flee,
    dead
}

