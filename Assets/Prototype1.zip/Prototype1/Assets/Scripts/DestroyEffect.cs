using System.Collections;
using UnityEngine;

public class DestroyEffect : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        Invoke(nameof(destroy), 2);
    }

    private IEnumerator destroy()
    {
        Destroy(gameObject);
        yield return null;
    }
}
