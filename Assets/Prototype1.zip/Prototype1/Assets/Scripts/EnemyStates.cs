using UnityEngine;

public enum EnemyStates
{
    idle,
    chase,
    attacking,
    dead
}


