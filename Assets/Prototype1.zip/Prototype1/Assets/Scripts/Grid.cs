using NUnit.Framework;
using System.Collections.Generic;
using UnityEngine;

public class Grid : MonoBehaviour
{
    public int gridWidth = 0;
    public int gridHeight = 0;
    public bool skip = false;
    private float cell = 1f;
    private bool walkable;

    public GameObject[] floorPrefabs;
    public GameObject rock;
    public GameObject enemy;
    public GameObject grass;
    public GameObject tree;
    public GameObject tree1;
    public GameObject tree2;
    public GameObject bush;
    public GameObject finish;
    public GameObject rager;

    Node[,] grid;

    private void Start()
    {
        GenerateGrid();
        if (!skip)
        {
            GenerateTrees();
        }
    }

    private void GenerateGrid()
    {
        //Grid is used to store world positions of each node
        grid = new Node[gridWidth, gridHeight];

        for (int x = 0; x < gridWidth; x++)
        {
            for (int y = 0; y < gridHeight; y++)
            {
                GameObject prefab = floorPrefabs[Random.Range(0, floorPrefabs.Length)];

                float chance = Random.Range(0, 100);

                Vector3 obstaclePos = new Vector3(x * cell, 0f, y * cell);
                Vector3 obstaclePos2 = new Vector3(x * cell, 0f, y * cell);

                if (chance <= 5 && (x != 45 || y != 45) && skip == false)
                {
                    Instantiate(rock, obstaclePos, Quaternion.identity);
                    walkable = false;
                }
                else if (chance >= 95 && skip == false)
                {
                    Instantiate(grass, obstaclePos2, Quaternion.identity);
                    walkable = true;
                }
                else
                {
                    walkable = true;
                    chance = Random.Range(0f, 100f);
                    if (chance <= 0.25f && (x != 45 || y != 45) && skip == false)
                    {
                        Instantiate(enemy, obstaclePos, Quaternion.identity);
                    }
                    if (chance >= 99.75f && (x != 45 || y != 45) && skip == false)
                    {
                        Instantiate(rager, obstaclePos, Quaternion.identity);
                    }
                }

                

                Vector3 position = new Vector3(x * cell, 0f, y * cell);
                if (x != 45 || y != 45)
                {
                    Instantiate(prefab, position, Quaternion.identity);
                }
                else
                {
                    Instantiate(finish, position, Quaternion.identity);
                }
                    grid[x, y] = new Node(walkable, position, x, y);
            }
        }
    }

    public Node NodeFromWorldPoint(Vector3 worldPoint)
    {
        //Allows for converting a players world position to a position on the grid
        //Convert world point to percentage of the grid
        float percentageX = worldPoint.x / gridWidth;
        //Debug.Log(percentageX);
        float percentageY = worldPoint.z / gridHeight;
        //Debug.Log(percentageY);

        percentageX = Mathf.Clamp01(percentageX);
        percentageY = Mathf.Clamp01(percentageY);

        int x = Mathf.RoundToInt(gridWidth * percentageX);
        int y = Mathf.RoundToInt(gridHeight * percentageY);

        return grid[x, y];
    }

    public List<Node> GetNeighbours(Node node)
    {
        //Get Neighbours checks the joining nodes to the selected node
        List<Node> neighbours = new List<Node>();
        
        for (int x = -1; x<=1; x++)
        {
            for(int y = -1; y<=1; y++)
            {
                if (x == 0 && y == 0) continue;

                int checkX = node.gridX + x;
                int checkY = node.gridY + y;

                if (checkX >= 0 && checkX < gridWidth && checkY >= 0 && checkY < gridHeight)
                {
                    neighbours.Add(grid[checkX, checkY]);
                }
            }
        }

        return neighbours;
    }

    private void GenerateTrees()
    {
        Vector3 spawnPos;
        for(int x = 0; x < 400;  x++)
        {
            if (x < 100)
            {
                spawnPos = new Vector3(Random.Range(-10, 60), 0, Random.Range(50, 60));
                Instantiate(tree, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 200)
            {
                spawnPos = new Vector3(Random.Range(50, 60), 0, Random.Range(-10, 60));
                Instantiate(tree, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 300)
            {
                spawnPos = new Vector3(Random.Range(-10, 0), 0, Random.Range(-10, 60));
                Instantiate(tree, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 400)
            {
                spawnPos = new Vector3(Random.Range(-10, 60), 0, Random.Range(-10, 0));
                Instantiate(tree, spawnPos, Quaternion.identity);
                continue;
            }
        }
        for (int x = 0; x < 400; x++)
        {
            if (x < 100)
            {
                spawnPos = new Vector3(Random.Range(-10, 60), 0, Random.Range(50, 60));
                Instantiate(tree1, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 200)
            {
                spawnPos = new Vector3(Random.Range(50, 60), 0, Random.Range(-10, 60));
                Instantiate(tree1, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 300)
            {
                spawnPos = new Vector3(Random.Range(-10, 0), 0, Random.Range(-10, 60));
                Instantiate(tree1, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 400)
            {
                spawnPos = new Vector3(Random.Range(-10, 60), 0, Random.Range(-10, 0));
                Instantiate(tree1, spawnPos, Quaternion.identity);
                continue;
            }
        }
        for (int x = 0; x < 400; x++)
        {
            if (x < 100)
            {
                spawnPos = new Vector3(Random.Range(-10, 60), 0, Random.Range(50, 60));
                Instantiate(tree2, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 200)
            {
                spawnPos = new Vector3(Random.Range(50, 60), 0, Random.Range(-10, 60));
                Instantiate(tree2, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 300)
            {
                spawnPos = new Vector3(Random.Range(-10, 0), 0, Random.Range(-10, 60));
                Instantiate(tree2, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 400)
            {
                spawnPos = new Vector3(Random.Range(-10, 60), 0, Random.Range(-10, 0));
                Instantiate(tree2, spawnPos, Quaternion.identity);
                continue;
            }
        }
        for (int x = 0; x < 400; x++)
        {
            if (x < 100)
            {
                spawnPos = new Vector3(Random.Range(-10, 60), 0, Random.Range(50, 60));
                Instantiate(bush, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 200)
            {
                spawnPos = new Vector3(Random.Range(50, 60), 0, Random.Range(-10, 60));
                Instantiate(bush, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 300)
            {
                spawnPos = new Vector3(Random.Range(-10, 0), 0, Random.Range(-10, 60));
                Instantiate(bush, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 400)
            {
                spawnPos = new Vector3(Random.Range(-10, 60), 0, Random.Range(-10, 0));
                Instantiate(bush, spawnPos, Quaternion.identity);
                continue;
            }
        }
        for (int x = 0; x < 400; x++)
        {
            if (x < 100)
            {
                spawnPos = new Vector3(Random.Range(-10, 60), 0, Random.Range(50, 60));
                Instantiate(rock, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 200)
            {
                spawnPos = new Vector3(Random.Range(50, 60), 0, Random.Range(-10, 60));
                Instantiate(rock, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 300)
            {
                spawnPos = new Vector3(Random.Range(-10, 0), 0, Random.Range(-10, 60));
                Instantiate(rock, spawnPos, Quaternion.identity);
                continue;
            }
            if (x < 400)
            {
                spawnPos = new Vector3(Random.Range(-10, 60), 0, Random.Range(-10, 0));
                Instantiate(rock, spawnPos, Quaternion.identity);
                continue;
            }
        }
        
    }
}
