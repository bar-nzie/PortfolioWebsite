using UnityEngine;

public class BossThrowable : MonoBehaviour
{
    enum throwingStages
    {
        Spawning,
        Moving,
        Destroy
    }

    [SerializeField] throwingStages currentState = throwingStages.Spawning;
    GameObject[] players;
    GameObject player;
    Vector3 lockOn;

    private void Start()
    {
    }

    private void Update()
    {
        switch (currentState)
        {
            case throwingStages.Spawning:
                Spawning();
                break;
            case throwingStages.Moving:
                Moving(); 
                break;
            case throwingStages.Destroy:
                Destroy();
                break;
        }
    }

    private void Spawning()
    {
        if (transform.localScale.x < 2)
        {
            transform.localScale += new Vector3(0.01f, 0.01f, 0.01f);
        }
        else
        {
            currentState = throwingStages.Moving;
            players = GameObject.FindGameObjectsWithTag("Player");
            player = players[0];
            lockOn = player.transform.position;
        }
    }

    private void Moving()
    {
        if (Vector3.Distance(transform.position, lockOn) > 0.1f)
        {
            transform.position = Vector3.MoveTowards(transform.position, lockOn, 7 * Time.deltaTime);
        }
        else
        {
            currentState = throwingStages.Destroy;
        }
    }

    private void Destroy()
    {
        Destroy(gameObject);
    }
}
