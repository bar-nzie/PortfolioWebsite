using System.Collections;
using UnityEngine;

public class CameraControl : MonoBehaviour
{
    private Vector3 pos1 = new Vector3(10, 5, -5);
    private Vector3 pos2 = new Vector3(-5, 5, 10);
    private Vector3 pos3 = new Vector3(24, 5, 10);
    private Vector3 pos4 = new Vector3(10, 5, 24);
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        transform.LookAt(new Vector3(10, 0, 10));
        if (Input.GetKeyDown(KeyCode.S))
        {
            StopAllCoroutines();
            StartCoroutine(MoveCam(pos1));
        }
        if (Input.GetKeyDown(KeyCode.A))
        {
            StopAllCoroutines();
            StartCoroutine(MoveCam(pos2));
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            StopAllCoroutines();
            StartCoroutine(MoveCam(pos4));
        }
        if (Input.GetKeyDown(KeyCode.D))
        {
            StopAllCoroutines();
            StartCoroutine(MoveCam(pos3));
        }
    }

    private IEnumerator MoveCam(Vector3 pos)
    {
        while (Vector3.Distance(transform.position, pos) > 0.01f)
        {
            transform.position = Vector3.MoveTowards(transform.position, pos, 10f * Time.deltaTime);
            yield return null;
        }
        yield return null;
    }
}
