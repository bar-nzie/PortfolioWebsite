using System.Collections;
using Unity.AppUI.UI;
using UnityEngine;

public class LaserTelegraph : MonoBehaviour
{
    [SerializeField] private LineRenderer line;
    [SerializeField] private Material attack;

    public void MiddleMan(Vector3 start, Vector3 end)
    {
        StartCoroutine(Attack(start, end));
    }

    public IEnumerator Attack(Vector3 start, Vector3 end)
    {
        line.enabled = true;
        line.SetPosition(0, start);
        line.SetPosition(1, end);
        yield return new WaitForSeconds(3f);
        line.material = attack;
        RaycastHit[] hits = Physics.RaycastAll(start, end - start, 50f);
        foreach (RaycastHit hit in hits)
        {
            if (hit.collider.tag == "Player")
            {
                Destroy(hit.collider.gameObject);
            }

        }
        yield return new WaitForSeconds(1f);

        Destroy(gameObject);
    }
}
