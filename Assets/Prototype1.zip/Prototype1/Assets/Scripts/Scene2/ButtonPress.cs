using System.Collections;
using Unity.Behavior;
using Unity.VisualScripting;
using UnityEngine;

public class ButtonPress : MonoBehaviour
{
    public BehaviorGraphAgent agent;
    public Vector3 startPos;
    public Vector3 endPos;
    public GameObject boss;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        endPos = boss.transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void ButtonPresser()
    {
        if (transform.localScale == new Vector3(0.5f, 0.5f, 0.5f))
        {
            agent.BlackboardReference.SetVariableValue("isPressed", true);
            startPos = transform.position;
            StartCoroutine(MoveTowards());
        }
    }
    public IEnumerator MoveTowards()
    {
        while(Vector3.Distance(transform.position, endPos) > 1)
        {
            transform.position = Vector3.MoveTowards(transform.position, endPos, Time.deltaTime);
            yield return null;
        }
        while(Vector3.Distance(transform.position, startPos) > 0.01)
        {
            transform.position = Vector3.MoveTowards(transform.position, startPos, Time.deltaTime);
            yield return null;
        }

        yield return null;
    }
}
