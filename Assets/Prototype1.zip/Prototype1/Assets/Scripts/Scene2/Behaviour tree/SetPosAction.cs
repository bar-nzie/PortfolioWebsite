using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "SetPos", story: "Set [Weapon] Pos to Above [Self]", category: "Action", id: "bae7ef1f250c3e2b889ab25f1d865956")]
public partial class SetPosAction : Action
{
    [SerializeReference] public BlackboardVariable<GameObject> Weapon;
    [SerializeReference] public BlackboardVariable<GameObject> Self;

    protected override Status OnUpdate()
    {
        Weapon.Value.transform.position = new Vector3(Self.Value.transform.position.x, 5, Self.Value.transform.position.z);
        Weapon.Value.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
        return Status.Success;
    }

    protected override void OnEnd()
    {
    }
}

