using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "GameObject to vector3", story: "Convert [Target] to [Location]", category: "Action", id: "acbbb3376be9347fb369e6e3715bc1e0")]
public partial class GameObjectToVector3Action : Action
{
    [SerializeReference] public BlackboardVariable<GameObject> Target;
    [SerializeReference] public BlackboardVariable<Vector3> Location;

    protected override Status OnUpdate()
    {
        Location.Value = Target.Value.transform.position;
        return Status.Success;
    }

}

