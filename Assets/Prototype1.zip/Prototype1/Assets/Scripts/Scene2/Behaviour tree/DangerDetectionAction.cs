using System;
using System.Collections.Generic;
using Unity.AppUI.UI;
using Unity.Behavior;
using Unity.Properties;
using UnityEngine;
using Action = Unity.Behavior.Action;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "Danger Detection", story: "[Self] shows [DangerZone]", category: "Action", id: "eb67d812458de8d0436fbe0b91e1c58b")]
public partial class DangerDetectionAction : Action
{
    [SerializeReference] public BlackboardVariable<GameObject> Self;
    [SerializeReference] public BlackboardVariable<List<GameObject>> DangerZone;
    [CreateProperty] private float m_Timer = 1.0f;
    Renderer rend;
    Color originalColour;
    int count = 0;
    RaycastHit[] hits;
    protected override Status OnStart()
    {
        m_Timer = 1.0f;

        return Status.Running;
    }

    protected override Status OnUpdate()
    {
        m_Timer -= Time.deltaTime;
        if (m_Timer <= 0)
        {
            foreach (RaycastHit hit in hits)
            {
                if (hit.collider.tag == "Ground")
                {
                    rend = hit.collider.gameObject.GetComponent<Renderer>();
                    rend.material.color = originalColour;
                }
            }
            return Status.Success;
        }

        hits = Physics.SphereCastAll(Self.Value.transform.position, 1, Vector3.down, 10f);
        if (count < 1)
        {
            rend = hits[5].collider.gameObject.GetComponent<Renderer>();
            originalColour = rend.material.color;
        }
        foreach (RaycastHit hit in hits)
        {
            if (hit.collider.tag == "Ground")
            {
                rend = hit.collider.gameObject.GetComponent<Renderer>();
                rend.material.color = Color.red;
            }
        }
        count++;
        return Status.Running;
    }

    protected override void OnEnd()
    {
    }
}

