using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "Shockwave", story: "[self] shall [shockwave]", category: "Action", id: "cc68c5f2bea204406909b86653d2e4eb")]
public partial class ShockwaveAction : Action
{
    [SerializeReference] public BlackboardVariable<GameObject> Self;
    [SerializeReference] public BlackboardVariable<GameObject> Shockwave;
    ParticleSystem system;

    protected override Status OnUpdate()
    {
        system = Shockwave.Value.GetComponent<ParticleSystem>();
        system.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
        system.Play();
        return Status.Success;
    }

    protected override void OnEnd()
    {
    }
}

