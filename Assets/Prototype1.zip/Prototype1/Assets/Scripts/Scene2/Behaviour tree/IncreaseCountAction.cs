using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "Increase Count", story: "[Count] Increase by 1", category: "Action", id: "f7f734b9b3a8c3dc28b93de38d872acd")]
public partial class IncreaseCountAction : Action
{
    [SerializeReference] public BlackboardVariable<int> Count;


    protected override Status OnUpdate()
    {
        Count.Value++;
        return Status.Success;
    }


}

