using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "Destroy", story: "Destroy [Target]", category: "Action", id: "1ff116d50756f078cd2e85e55a2a9ad8")]
public partial class DestroyAction : Action
{
    [SerializeReference] public BlackboardVariable<GameObject> Target;
    Renderer rend;
    float elapsed = 0;

    protected override Status OnStart()
    {
        rend = Target.Value.gameObject.GetComponent<Renderer>();
        rend.material.color = Color.red;
        elapsed = 0;
        return Status.Running;
    }

    protected override Status OnUpdate()
    {
        if (elapsed > 1)
        {
            Target.Value.SetActive(false);
            elapsed = 0;
            return Status.Success;
        }
        elapsed += Time.deltaTime;
        return Status.Running;
    }

    protected override void OnEnd()
    {
    }
}

