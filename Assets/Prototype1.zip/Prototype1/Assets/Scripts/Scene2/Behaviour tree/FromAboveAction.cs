using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "From Above", story: "Change [Target] to [Location] above", category: "Action", id: "a85ad8cf9ddf5e30d70e11539066f22c")]
public partial class FromAboveAction : Action
{
    [SerializeReference] public BlackboardVariable<GameObject> Target;
    [SerializeReference] public BlackboardVariable<Vector3> Location;

    protected override Status OnUpdate()
    {
        GameObject target = Target;
        Location.Value = (BlackboardVariable<Vector3>)new Vector3(target.transform.position.x, 5, target.transform.position.z);

        if(Location == null)
        {
            return Status.Failure;
        }
        return Status.Success;
    }

}

