using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "Random Attack", story: "Assign [Target] to random location with tag [Tag]", category: "Action", id: "3859649a5b30d3b921a3c1b5d28e2c4b")]
public partial class RandomAttackAction : Action
{
    [SerializeReference] public BlackboardVariable<GameObject> Target;
    [SerializeReference] public BlackboardVariable<string> Tag;

    protected override Status OnUpdate()
    {
        GameObject[] tagged = GameObject.FindGameObjectsWithTag(Tag);

        if (tagged == null || tagged.Length == 0)
        {
            return Status.Failure;
        }

        int randomNumber = UnityEngine.Random.Range(0, tagged.Length);
        Target.Value = tagged[randomNumber];
        return Status.Success;
    }

}

