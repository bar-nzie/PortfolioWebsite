using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "Slam Attack", story: "[Location] to zero", category: "Action", id: "9bd344d4400018d27d735667a33cbb73")]
public partial class SlamAttackAction : Action
{
    [SerializeReference] public BlackboardVariable<Vector3> Location;

    protected override Status OnUpdate()
    {
        Location.Value = new Vector3(Location.Value.x, 1.5f, Location.Value.z);
        return Status.Success;
    }

}

