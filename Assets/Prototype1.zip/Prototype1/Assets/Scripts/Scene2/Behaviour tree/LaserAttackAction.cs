using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "Laser Attack", story: "Instantiate [Lasers]", category: "Action", id: "fe88bd03b7db8e8dace221296b61f65a")]
public partial class LaserAttackAction : Action
{
    [SerializeReference] public BlackboardVariable<GameObject> Lasers;
    private LaserTelegraph laser;

    protected override Status OnUpdate()
    {
        Vector3 pos = new Vector3(1, 0.75f, -1);
        Vector3 posz = new Vector3(1, 0.75f, 21);
        GameObject current;
        for (int i = 0; i < 10; i++)
        {
            current = GameObject.Instantiate(Lasers.Value);
            laser = current.GetComponent<LaserTelegraph>();
            laser.MiddleMan(pos, posz);
            pos += new Vector3(2, 0, 0);
            posz += new Vector3(2, 0, 0);
        }
        pos = new Vector3(-1, 0.75f, 1);
        posz = new Vector3(21, 0.75f, 1);
        for (int i = 0; i < 10; i++)
        {
            current = GameObject.Instantiate(Lasers.Value);
            laser = current.GetComponent<LaserTelegraph>();
            laser.MiddleMan(pos, posz);
            pos += new Vector3(0, 0, 2);
            posz += new Vector3(0, 0, 2);
        }
        return Status.Success;
    }

    protected override void OnEnd()
    {
    }

}

