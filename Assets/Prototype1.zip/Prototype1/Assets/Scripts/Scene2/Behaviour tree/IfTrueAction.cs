using System;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "IfTrue", story: "[isPressed] True?", category: "Action", id: "c3683cc639f073aea54844913296dc96")]
public partial class IfTrueAction : Action
{
    [SerializeReference] public BlackboardVariable<bool> IsPressed;

    protected override Status OnStart()
    {
        if (IsPressed)
        {
            return Status.Success;
        }
        return Status.Failure;
    }

}

