using System;
using System.Collections.Generic;
using Unity.Behavior;
using UnityEngine;
using Action = Unity.Behavior.Action;
using Unity.Properties;

[Serializable, GeneratePropertyBag]
[NodeDescription(name: "Choose Symbol", story: "Choose [Target] from [Symbol]", category: "Action", id: "f414ac76a78265f416fde450917e0d93")]
public partial class ChooseSymbolAction : Action
{
    [SerializeReference] public BlackboardVariable<GameObject> Target;
    [SerializeReference] public BlackboardVariable<List<GameObject>> Symbol;



    protected override Status OnUpdate()
    {
        int randomNumber = UnityEngine.Random.Range(0, Symbol.Value.Count);
        Target.Value = Symbol.Value[randomNumber];
        return Status.Success;
    }

    protected override void OnEnd()
    {
    }
}

